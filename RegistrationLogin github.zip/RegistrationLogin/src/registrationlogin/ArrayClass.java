package ArrayClass;
import java.util.ArrayList;
public class ArrayClass {
    
static ArrayList<String> sentMessages = new ArrayList<>();
   static ArrayList<String> disregardedMessages = new ArrayList<>();
  static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> messageHash = new ArrayList<>();
        static ArrayList<String> messageID = new ArrayList<>();
    static int index = 0;
    public static void main(String[] args) {
   sendMessage("Hello, how are you?");
     sendMessage("Welcome to my Java program.");
    storedMessages.add("Hello, how are you?");
            storedMessages.add("Welcome to my Java program.");
     messageID("Hello, how are you?");
     messageID("Welcome to my Java program.");
        allStoredMessages();
      longStoredMessages();
      getByID(0);
    }
    public static void sendMessage(String mess) {
        sentMessages.add(mess);
    index++;
    }
 public static void disregardedMessages() {
   for (int i = sentMessages.size() - 1; i >= 0; i--) {
      disregardedMessages.add(sentMessages.get(i));
       sentMessages.remove(i);
        }
        index = 0;
    }
    public static void allStoredMessages() {
      System.out.println("All stored messages:");
    for (int i = 0; i < storedMessages.size(); i++) {
     System.out.println(storedMessages.get(i));
        }
    }

    public static void longStoredMessages() {
        if (storedMessages.isEmpty()) {
            System.out.println("No stored messages.");
            return;
        }
    int a = 0;
     int k = 0;
        for (int i = 0; i < storedMessages.size(); i++) {
       String b = storedMessages.get(i);
    int c = b.length();
    
  if (c > a) {
     a = c;
     k = i;
            }
        }
        
        System.out.println("Longest message: " + storedMessages.get(k));
    }
    public static void messageHash() {
        messageHash.clear();
      for (int i = 0; i < sentMessages.size(); i++) {
     String mess = sentMessages.get(i);
      String hash = Integer.toHexString(mess.hashCode());
      messageHash.add(hash);
        }
    }
    public static void messageID(String mess) {
        messageID.add(index + ": " + mess);
    }
  public static void increm() {
     index++;
    }
    public static void getByID(int targetIndex) {
     if (targetIndex >= 0 && targetIndex < messageID.size()) {
 System.out.println(messageID.get(targetIndex));
        } else {
            System.out.println("Index out of bounds.");
        }
    }
}