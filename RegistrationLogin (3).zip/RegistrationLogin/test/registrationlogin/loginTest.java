/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package registrationlogin;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class loginTest {
    
    public loginTest() {
    }
    
    /**
     * Test of checkUsername method, of class login.
     */
    @Test
    public void testTrueCheckUsername() {
        System.out.println("checkUsername");
        String username = "kyl_1";
        login instance = new login();
        boolean expResult = true;
        boolean result = instance.checkUsername(username);
        assertEquals(expResult, result);
    }
    @Test
    public void testFalseCheckUsername() {
        System.out.println("checkUsername");
        String username = "kyl_1!!!!!!!!!!!!!";
        login instance = new login();
        boolean expResult = false;
        boolean result = instance.checkUsername(username);
        assertEquals(expResult, result);
    }

    /**
     * Test of checkPasswordComplexity method, of class login.
     */
    @Test
    public void testFalseCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "password";
        login instance = new login();
        boolean expResult = false;
        boolean result = instance.checkPasswordComplexity(password);
        assertEquals(expResult, result);
        
    }
 /**
     * Test of checkPasswordComplexity method, of class login.
     */
    @Test
    public void testTrueCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "Ch&&sec@ke99!";
        login instance = new login();
        boolean expResult = true;
        boolean result = instance.checkPasswordComplexity(password);
        assertEquals(expResult, result);
        
    }
    /**
     * Test of checkCellPhoneNumber method, of class login.
     */
    @Test
    public void testTrueCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        String CellPhoneNumber = "+27838968976";
        login instance = new login();
        boolean expResult = true;
        boolean result = instance.checkCellPhoneNumber(CellPhoneNumber);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
/**
     * Test of checkCellPhoneNumber method, of class login.
     */
    @Test
    public void testFalseCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        String CellPhoneNumber = "08966553";
        login instance = new login();
        boolean expResult = false;
        boolean result = instance.checkCellPhoneNumber(CellPhoneNumber);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    /**
     * Test of registerUser method, of class login.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String username = "";
        String password = "";
        String cellnum = "";
        login instance = new login();
        String expResult = "";
        String result = instance.registerUser(username, password, cellnum);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String username = "";
        String password = "";
        String newUsername = "";
        String newPassword = "";
        login instance = new login();
        boolean expResult = false;
        boolean result = instance.loginUser(username, password, newUsername, newPassword);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnLoginStatus method, of class login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean LoginSuccessful = false;
        login instance = new login();
        String expResult = "";
        String result = instance.returnLoginStatus(LoginSuccessful);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
