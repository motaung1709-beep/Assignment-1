package registrationlogin;
import java.util.Scanner;
import java.util.Random;
public class messages {

    // Create an object to use the methods from the login class
    static login log = new login();

    // Keep track of how many messages have been sent
    private static int totalMessagesSent = 0;

    // This is where the program starts running
    public static void main(String[] args) {

        new messages().part();
    }

  // This method makes sure the user enters a whole number
    private static int readInt(Scanner scan, String prompt) {

        while (true) {
            System.out.print(prompt);

            String line = scan.nextLine().trim();

            try {
            
                return Integer.parseInt(line);

            } catch (NumberFormatException e) {

                // Show an error if the user does not enter a whole number
                System.out.println("Invalid input. Please enter a whole number.");
            }
        }
    }

   
    public void part() {

        // Create a Scanner to read the user's input
        Scanner scan = new Scanner(System.in);
        int option;

        // Keep showing the menu until the user chooses to quit
        do {
            System.out.println("\nWelcome to QuickChat");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");

            // Ask the user to choose an option
            option = readInt(scan, "Choose an option: ");

            // Check which option the user selected
            if (option == 1) {

                // Call the method to send messages
                sendMessages(scan);

            } else if (option == 2) {

                // This feature has not been completed yet
                System.out.println("Coming soon");

            } else if (option == 3) {

                // Display a message when the user exits
                System.out.println("Thanks for using QuickChat");

            } else {

                // Display an error if the option is incorrect
                System.out.println("Error!! Invalid input");
            }

        } while (option != 3);

        scan.close();
    }
    public static String generateMessageID() {
        Random ran = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(ran.nextInt(10));
        }

      
        return id.toString();
    }

    // This method creates a hash for the message
    public static String generateMessageHash(
            String messageID, int messageNumber, String messageText) {

        // Get the first two characters of the message ID
        String firstTwoID = messageID.substring(0, 2);

        // Remove extra spaces at the beginning and end of the message
        String trimmed = messageText.trim();

        // Check if the message is empty
        if (trimmed.isEmpty()) {

            // Return the hash without any words
            return firstTwoID + ":" + messageNumber + ":";
        }

        // Split the message into words using spaces
        String[] words = trimmed.split("\\s+");

        // Join the first and last words and change them to uppercase
        String combinedWords =
                (words[0] + words[words.length - 1]).toUpperCase();

        // Return the completed message hash
        return firstTwoID + ":" + messageNumber + ":" + combinedWords;
    }

    // This method checks if the message is 250 characters or less
    public static boolean checkMessageLength(String message) {

 
        return message.length() <= 250;
    }

    // This method allows the user to enter and send messages
    public static void sendMessages(Scanner scan) {

        // Ask the user how many messages they want to send
        int n = readInt(scan, "How many messages do you want to send: ");

  
        if (n <= 0) {

            // Display an error if the number is not valid
            System.out.println("Number of messages must be greater than 0.");
            return;
        }

        // Repeat the process for each message
        for (int i = 0; i < n; i++) {

            // Show which message the user is busy with
            System.out.println("\n--- Message " + (i + 1) + " of " + n + " ---");

            // Create a variable to store the recipient's cellphone number
            String recNo;

            // Keep asking until the cellphone number is correct
            while (true) {
                System.out.print("Enter recipient cell number: ");

                // Read the cellphone number entered by the user
                recNo = scan.nextLine().trim();

                // Check if the cellphone number is valid
                if (log.checkCellPhoneNumber(recNo)) {
                    break;
                }

                // Ask the user to enter the number again if it is incorrect
                System.out.println("Invalid recipient number format! Please try again.");
            }

            // Create a variable to store the message
            String messageText;

            // Keep asking until the message is valid
            while (true) {
                System.out.print("Enter message: ");

                // Read the message entered by the user
                messageText = scan.nextLine();

                // Check if the message is longer than 250 characters
                if (!checkMessageLength(messageText)) {

                    // Display an error if the message is too long
                    System.out.println("Please enter a message of 250 characters or less.");

                // Check if the user entered an empty message
                } else if (messageText.trim().isEmpty()) {

                    // Ask the user to enter a message
                    System.out.println("Message cannot be empty.");

                } else {

                    // Stop asking when the message is valid
                    break;
                }
            }

            // Display the options for what to do with the message
            System.out.println("\nChoose an option:");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");

            // Get the option selected by the user
            int choice = readInt(scan, "Enter choice (1-3): ");

            // Check if the user wants to send the message
            if (choice == 1) {

                // Add one to the total number of messages sent
                totalMessagesSent++;

                // Generate an ID for the message
                String messageID = generateMessageID();

                // Create a hash for the message
                String messageHash = generateMessageHash(
                    messageID, totalMessagesSent, messageText
                );

                // Display the details of the message that was sent
                System.out.println("Message successfully sent");
                System.out.println("Message ID: " + messageID);
                System.out.println("Message Hash: " + messageHash);
                System.out.println("Recipient: " + recNo);
                System.out.println("Message: " + messageText);

            // Check if the user wants to delete the message
            } else if (choice == 2) {

                // Ask the user to confirm the deletion
                System.out.print("Press 0 to delete the message: ");

                // Read the user's answer
                String confirm = scan.nextLine().trim();

                // Check if the user entered 0
                if (confirm.equals("0")) {

                    // Display a message to confirm deletion
                    System.out.println("Message deleted.");

                } else {

                    // Display a message if the user does not confirm
                    System.out.println("Message not deleted.");
                }

            // Check if the user wants to store the message
            } else if (choice == 3) {

                // Display a message to confirm that it was stored
                System.out.println("Message successfully stored");

            } else {

                // Display an error if the user enters an incorrect option
                System.out.println("Invalid choice.");
            }
        }

        // Display a line to separate the final summary
        System.out.println("\n========================================");

        // Show the total number of messages sent
        System.out.println("Total messages processed/sent: " + totalMessagesSent);

        // Display the closing line
        System.out.println("========================================");
    }
}