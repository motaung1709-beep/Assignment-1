package registrationlogin;

import java.util.Scanner;

public class RegistrationLogin {

    public static void main(String[] args) {
        messages mess = new messages();
//Create an object of the login        
        login log = new login();
//Create an scanner object to get input
        Scanner scanner = new Scanner(System.in);
//Display where the user enters their name        
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
//Check if the username is valid        
        if (log.checkUsername(username)) {
            System.out.println("User name successfuly captured");
//Display where the the user enters password            
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
//Check if the password is valid            
            if (log.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured");
                System.out.print("Enter phone number: ");
                String regex = scanner.nextLine();
//Check if the number is correct
                if (log.checkCellPhoneNumber(regex)) {
                    System.out.println("Cellphone number successfully added");
//Display that it has been successfully registered            
                    System.out.println("Account created successfully");
                    System.out.println("====Login=====");
                    System.out.print("Enter your username: ");
                    String newUser = scanner.nextLine();
                    System.out.print("Enter your password: ");
                    String newPass = scanner.nextLine();
                    if (log.loginUser(username, password, newUser, newPass)) {
                        System.out.println("Login successfull");
                        System.out.println("Welcome, it is great to see you");
                        
                        mess.part();
                    } else {
//Display an error if details are invalid                        
                        System.out.println("Login unsuccessfull");
                    }
//Display an error if the number is not valid                     
                } else {
                    System.out.println("Cellphone number incorrectly formatted or does not contain international code");
                }
//Display an error if the password is not valid                
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character");
            }
//Display an error if the username is not valid            
        } else {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length");
        }

    }

}
